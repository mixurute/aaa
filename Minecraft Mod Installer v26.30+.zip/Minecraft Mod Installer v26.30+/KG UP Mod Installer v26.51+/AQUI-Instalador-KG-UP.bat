@echo off
setlocal enabledelayedexpansion
title KG UP - Mod Installer v26.x+ (Funciona nas versoes mais recentes)


net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath \"%~f0\" -Verb RunAs" >nul 2>&1
    if errorlevel 1 (
        color 0c
        echo ========================================================
        echo [ERRO] FALHA AO SOLICITAR PERMISSAO DE ADMINISTRADOR
        echo ========================================================
        echo.
        echo O Windows impediu que o instalador pedisse permissao
        echo automaticamente. Por favor, clique com o BOTAO DIREITO
        echo no arquivo e selecione "Executar como Administrador".
        echo.
        pause
    )
    exit /b
)
cd /d "%~dp0"

echo "%~dp0" | findstr /i /c:"\AppData\Local\Temp" >nul
if %errorlevel% equ 0 (
    color 0c
    echo ========================================================
    echo [ERRO] VOCE ESTA EXECUTANDO DENTRO DE UM ARQUIVO ZIP!
    echo ========================================================
    echo.
    echo Por favor, extraia ^(descompacte^) a pasta completa para a
    echo sua Area de Trabalho ou outro local antes de executar.
    echo.
    pause
    exit /b
)

reg add "HKCU\Console" /v VirtualTerminalLevel /t REG_DWORD /d 1 /f >nul 2>&1
for /f %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"

set "R=%ESC%[0m"
set "B=%ESC%[1m"
set "CYN=%ESC%[96m"
set "RED=%ESC%[91m"
set "GRN=%ESC%[92m"
set "YLW=%ESC%[93m"
set "WHT=%ESC%[97m"
set "DIM=%ESC%[90m"

set "LANG=en"
for /f "delims=" %%L in ('powershell -NoProfile -Command "(Get-Culture).TwoLetterISOLanguageName"') do set "SYS_LANG=%%L"

if /i "!SYS_LANG!"=="pt" set "LANG=pt"
if /i "!SYS_LANG!"=="es" set "LANG=es"

if "!LANG!"=="pt" (
    set "STR_MENU_TITLE=MOD INSTALLER"
    set "STR_OPT1=Instalar Mods"
    set "STR_OPT2=Desinstalar Mods"
    set "STR_OPT3=Sair"
    set "STR_CHOICE=Sua escolha: "
    set "STR_HINT=Apenas digite 1, 2 ou 3 e aperte ENTER."
    set "STR_INVALID=Opcao invalida. Tente novamente."
    set "STR_SEARCHING=Procurando Minecraft..."
    set "STR_FOUND=Encontrado"
    set "STR_NOT_FOUND=[ERRO] Sua pasta do Minecraft nao foi encontrada para a instalacao. Geralmente e porque houve alguma falha na instalacao do seu Minecraft ou voce nao abriu e fechou o jogo pelo menos 1 vez. Se mesmo assim nao resolver, reinstale o Minecraft apagando a pasta (Win + R, digite %%appdata%%, apague a pasta Minecraft Bedrock) e instale novamente pela Microsoft Store."
    set "STR_RUNNING=[AVISO] Minecraft esta aberto! Feche o jogo e tente novamente."
    set "STR_BACKUP=Fazendo backup do original..."
    set "STR_BACKUP_OK=Backup salvo."
    set "STR_INST_VC=Instalando vcruntime140_1.dll..."
    set "STR_INST_MOD=Instalando KG-UP-GOAT.dll..."
    set "STR_INST_OK=INSTALACAO CONCLUIDA COM SUCESSO!"
    set "STR_RESTART=Reinicie o Minecraft para aplicar as mudancas."
    set "STR_ERR_VC=[ERRO] Falha ao instalar vcruntime140_1.dll."
    set "STR_ERR_MOD=[ERRO] Falha ao instalar KG-UP-GOAT.dll."
    set "STR_ERR_DLL=[ERRO] Arquivo nao encontrado na pasta do instalador."
    set "STR_ERR_DATA=[ERRO] Pasta do jogo nao encontrada. Abra o Minecraft, crie um Mundo e tente novamente."
    set "STR_ERR_PATH=[ERRO] Caminho do Minecraft invalido."
    set "STR_UNIN_TITLE=DESINSTALACAO DE MODS"
    set "STR_RESTORE=Restaurando vcruntime original..."
    set "STR_RESTORE_OK=vcruntime140_1.dll restaurado!"
    set "STR_NO_BKP=Sem backup encontrado. Removendo vcruntime modificado..."
    set "STR_NO_VC=vcruntime140_1.dll nao encontrado na pasta do Minecraft."
    set "STR_RM_MOD=Removendo KG-UP-GOAT.dll..."
    set "STR_RM_OK=KG-UP-GOAT.dll removido!"
    set "STR_NO_MOD=KG-UP-GOAT.dll nao encontrado na pasta de mods."
    set "STR_UNIN_OK=DESINSTALACAO CONCLUIDA!"
    set "STR_UNIN_MSG=Minecraft restaurado ao estado original."
    set "STR_PRESS=Pressione qualquer tecla para voltar ao menu..."
    set "STR_GOODBYE=Obrigado por usar o KG UP Mod Installer!"
    set "STR_COMM_Q=O mod funcionou para voce?"
    set "STR_COMM_MSG=Se sim, considere se inscrever e deixar o like no canal!"
    set "STR_COMM_DC=Voce tambem pode entrar na nossa comunidade do Discord!"
    set "STR_COMM_OPT1=Abrir YouTube e Discord"
    set "STR_COMM_OPT2=Nao, obrigado"
    set "STR_VC_TITLE=DEPENDENCIAS NECESSARIAS"
    set "STR_VC_MSG=O Minecraft precisa do Visual C++ Redistributable (x86 e x64) para funcionar."
    set "STR_VC_X64=Visual C++ x64: "
    set "STR_VC_X86=Visual C++ x86: "
    set "STR_VC_PRESENT=INSTALADO"
    set "STR_VC_MISSING=NAO ENCONTRADO"
    set "STR_VC_OPT1=Instalar agora"
    set "STR_VC_OPT2=Continuar sem instalar"
    set "STR_VC_INSTALLING=Instalando dependencias, aguarde..."
    set "STR_VC_DONE=Dependencias instaladas com sucesso!"
    set "STR_VC_ERR=[ERRO] Falha ao instalar. Tente manualmente."
    set "STR_VC_NO_FILE=[ERRO] Instalador nao encontrado em VC_redist_dependencia\"
) else if "!LANG!"=="es" (
    set "STR_MENU_TITLE=INSTALADOR DE MODS"
    set "STR_OPT1=Instalar Mods"
    set "STR_OPT2=Desinstalar Mods"
    set "STR_OPT3=Salir"
    set "STR_CHOICE=Tu eleccion: "
    set "STR_HINT=Solo escribe 1, 2 o 3 y presiona ENTER."
    set "STR_INVALID=Opcion invalida. Intentalo de nuevo."
    set "STR_SEARCHING=Buscando Minecraft..."
    set "STR_FOUND=Encontrado"
    set "STR_NOT_FOUND=[ERROR] No se encontro la carpeta de Minecraft para la instalacion. Generalmente es por una falla en la instalacion o no abriste y cerraste el juego al menos una vez. Si no se resuelve, reinstala Minecraft eliminando la carpeta (Win + R, escribe %%appdata%%, elimina Minecraft Bedrock) y vuelve a instalar desde Microsoft Store."
    set "STR_RUNNING=[AVISO] Minecraft esta abierto! Cierra el juego e intentalo de nuevo."
    set "STR_BACKUP=Haciendo copia de seguridad..."
    set "STR_BACKUP_OK=Copia de seguridad guardada."
    set "STR_INST_VC=Instalando vcruntime140_1.dll..."
    set "STR_INST_MOD=Instalando KG-UP-GOAT.dll..."
    set "STR_INST_OK=INSTALACION COMPLETADA CON EXITO!"
    set "STR_RESTART=Reinicia Minecraft para aplicar los cambios."
    set "STR_ERR_VC=[ERROR] Fallo al instalar vcruntime140_1.dll."
    set "STR_ERR_MOD=[ERROR] Fallo al instalar KG-UP-GOAT.dll."
    set "STR_ERR_DLL=[ERROR] Archivo no encontrado en la carpeta del instalador."
    set "STR_ERR_DATA=[ERROR] Carpeta del juego no encontrada. Abre Minecraft, crea un Mundo e intentalo de nuevo."
    set "STR_ERR_PATH=[ERROR] Ruta de Minecraft invalida."
    set "STR_UNIN_TITLE=DESINSTALACION DE MODS"
    set "STR_RESTORE=Restaurando vcruntime original..."
    set "STR_RESTORE_OK=vcruntime140_1.dll restaurado!"
    set "STR_NO_BKP=Sin copia de seguridad. Eliminando vcruntime modificado..."
    set "STR_NO_VC=vcruntime140_1.dll no encontrado en la carpeta de Minecraft."
    set "STR_RM_MOD=Eliminando KG-UP-GOAT.dll..."
    set "STR_RM_OK=KG-UP-GOAT.dll eliminado!"
    set "STR_NO_MOD=KG-UP-GOAT.dll no encontrado en la carpeta de mods."
    set "STR_UNIN_OK=DESINSTALACION COMPLETADA!"
    set "STR_UNIN_MSG=Minecraft restaurado a su estado original."
    set "STR_PRESS=Presiona cualquier tecla para volver al menu..."
    set "STR_GOODBYE=Gracias por usar KG UP Mod Installer!"
    set "STR_COMM_Q=El mod funciono para ti?"
    set "STR_COMM_MSG=Si es asi, suscribete y deja un like en el canal!"
    set "STR_COMM_DC=Tambien puedes unirte a nuestra comunidad de Discord!"
    set "STR_COMM_OPT1=Abrir YouTube y Discord"
    set "STR_COMM_OPT2=No, gracias"
    set "STR_VC_TITLE=DEPENDENCIAS NECESARIAS"
    set "STR_VC_MSG=Minecraft necesita Visual C++ Redistributable (x86 y x64) para funcionar."
    set "STR_VC_X64=Visual C++ x64: "
    set "STR_VC_X86=Visual C++ x86: "
    set "STR_VC_PRESENT=INSTALADO"
    set "STR_VC_MISSING=NO ENCONTRADO"
    set "STR_VC_OPT1=Instalar ahora"
    set "STR_VC_OPT2=Continuar sin instalar"
    set "STR_VC_INSTALLING=Instalando dependencias, espera..."
    set "STR_VC_DONE=Dependencias instaladas con exito!"
    set "STR_VC_ERR=[ERROR] Fallo al instalar. Intentalo manualmente."
    set "STR_VC_NO_FILE=[ERROR] Instalador no encontrado en VC_redist_dependencia\"
) else (
    set "STR_MENU_TITLE=MOD INSTALLER"
    set "STR_OPT1=Install Mods"
    set "STR_OPT2=Uninstall Mods"
    set "STR_OPT3=Exit"
    set "STR_CHOICE=Your choice: "
    set "STR_HINT=Just type 1, 2 or 3 and press ENTER."
    set "STR_INVALID=Invalid option. Try again."
    set "STR_SEARCHING=Searching for Minecraft..."
    set "STR_FOUND=Found"
    set "STR_NOT_FOUND=[ERROR] Minecraft folder not found for installation. Usually, it's due to an installation failure or you haven't opened and closed the game at least once. If it persists, reinstall Minecraft by deleting the folder (Win + R, type %%appdata%%, delete Minecraft Bedrock) and install again from the Microsoft Store."
    set "STR_RUNNING=[WARNING] Minecraft is running! Close the game and try again."
    set "STR_BACKUP=Backing up original file..."
    set "STR_BACKUP_OK=Backup saved."
    set "STR_INST_VC=Installing vcruntime140_1.dll..."
    set "STR_INST_MOD=Installing KG-UP-GOAT.dll..."
    set "STR_INST_OK=INSTALLATION COMPLETED SUCCESSFULLY!"
    set "STR_RESTART=Restart Minecraft to apply the changes."
    set "STR_ERR_VC=[ERROR] Failed to install vcruntime140_1.dll."
    set "STR_ERR_MOD=[ERROR] Failed to install KG-UP-GOAT.dll."
    set "STR_ERR_DLL=[ERROR] File not found in installer folder."
    set "STR_ERR_DATA=[ERROR] Game folder not found. Open Minecraft, create a World, and try again."
    set "STR_ERR_PATH=[ERROR] Invalid Minecraft path."
    set "STR_UNIN_TITLE=UNINSTALL MODS"
    set "STR_RESTORE=Restoring original vcruntime..."
    set "STR_RESTORE_OK=vcruntime140_1.dll restored!"
    set "STR_NO_BKP=No backup found. Removing modified vcruntime..."
    set "STR_NO_VC=vcruntime140_1.dll not found in Minecraft folder."
    set "STR_RM_MOD=Removing KG-UP-GOAT.dll..."
    set "STR_RM_OK=KG-UP-GOAT.dll removed!"
    set "STR_NO_MOD=KG-UP-GOAT.dll not found in mods folder."
    set "STR_UNIN_OK=UNINSTALLATION COMPLETE!"
    set "STR_UNIN_MSG=Minecraft has been restored to its original state."
    set "STR_PRESS=Press any key to return to the menu..."
    set "STR_GOODBYE=Thank you for using KG UP Mod Installer!"
    set "STR_COMM_Q=Did the mod work for you?"
    set "STR_COMM_MSG=If so, consider subscribing and leaving a like on the channel!"
    set "STR_COMM_DC=You can also join our Discord community!"
    set "STR_COMM_OPT1=Open YouTube and Discord"
    set "STR_COMM_OPT2=No, thanks"
    set "STR_VC_TITLE=REQUIRED DEPENDENCIES"
    set "STR_VC_MSG=Minecraft requires Visual C++ Redistributable (x86 and x64) to work."
    set "STR_VC_X64=Visual C++ x64: "
    set "STR_VC_X86=Visual C++ x86: "
    set "STR_VC_PRESENT=INSTALLED"
    set "STR_VC_MISSING=NOT FOUND"
    set "STR_VC_OPT1=Install now"
    set "STR_VC_OPT2=Continue without installing"
    set "STR_VC_INSTALLING=Installing dependencies, please wait..."
    set "STR_VC_DONE=Dependencies installed successfully!"
    set "STR_VC_ERR=[ERROR] Installation failed. Try manually."
    set "STR_VC_NO_FILE=[ERROR] Installer not found in VC_redist_dependencia\"
)

set "MODS_DIR=%APPDATA%\Minecraft Bedrock\mods"
set "BKP_DIR=%APPDATA%\Minecraft Mod Installer\backups"
set "INST_DIR=%~dp0"

set "VC_X64_OK=0"
set "VC_X86_OK=0"
reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64" /v Installed >nul 2>&1 && set "VC_X64_OK=1"
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x86" /v Installed >nul 2>&1 && set "VC_X86_OK=1"

if "!VC_X64_OK!"=="1" if "!VC_X86_OK!"=="1" goto MENU

cls
echo.
echo %B%%YLW%   ===============================================%R%
echo %B%%YLW%              !STR_VC_TITLE!%R%
echo %B%%YLW%   ===============================================%R%
echo.
echo %WHT%   !STR_VC_MSG!%R%
echo.
if "!VC_X64_OK!"=="1" (
    echo   %GRN%   !STR_VC_X64!!STR_VC_PRESENT!%R%
) else (
    echo   %RED%   !STR_VC_X64!!STR_VC_MISSING!%R%
)
if "!VC_X86_OK!"=="1" (
    echo   %GRN%   !STR_VC_X86!!STR_VC_PRESENT!%R%
) else (
    echo   %RED%   !STR_VC_X86!!STR_VC_MISSING!%R%
)
echo.
echo   %CYN%[1]%WHT% !STR_VC_OPT1!%R%
echo   %DIM%[2] !STR_VC_OPT2!%R%
echo.
set "VOP="
set /p "VOP=   %WHT%!STR_CHOICE!%R%"

if "!VOP!"=="2" goto MENU
if "!VOP!" neq "1" goto MENU

cls
echo.
echo %WHT%   !STR_VC_INSTALLING!%R%
echo.

set "VC_DIR=%INST_DIR%VC_redist_dependencia"
set "VC_ERR=0"

if "!VC_X64_OK!"=="0" (
    set "VC64_EXE="
    for %%f in ("!VC_DIR!\vc_redist.x64.exe" "!VC_DIR!\VC_redist.x64.exe" "!VC_DIR!\vcredist_x64.exe") do (
        if exist "%%~f" if not defined VC64_EXE set "VC64_EXE=%%~f"
    )
    if not defined VC64_EXE (
        echo %RED%   !STR_VC_NO_FILE! (x64)%R%
        set "VC_ERR=1"
    ) else (
        echo %WHT%   x64...%R%
        start /wait "" "!VC64_EXE!" /install /passive /norestart
        if !errorlevel! equ 0 (
            echo %GRN%   [OK] x64%R%
        ) else if !errorlevel! equ 3010 (
            echo %GRN%   [OK] x64 ^(Reinicio recomendado depois^)%R%
        ) else if !errorlevel! equ 1638 (
            echo %GRN%   [OK] x64 ^(Ja instalado^)%R%
        ) else (
            echo %RED%   !STR_VC_ERR! (x64) [Cod: !errorlevel!]%R%
            set "VC_ERR=1"
        )
    )
)

if "!VC_X86_OK!"=="0" (
    set "VC86_EXE="
    for %%f in ("!VC_DIR!\vc_redist.x86.exe" "!VC_DIR!\VC_redist.x86.exe" "!VC_DIR!\vcredist_x86.exe") do (
        if exist "%%~f" if not defined VC86_EXE set "VC86_EXE=%%~f"
    )
    if not defined VC86_EXE (
        echo %RED%   !STR_VC_NO_FILE! (x86)%R%
        set "VC_ERR=1"
    ) else (
        echo %WHT%   x86...%R%
        start /wait "" "!VC86_EXE!" /install /passive /norestart
        if !errorlevel! equ 0 (
            echo %GRN%   [OK] x86%R%
        ) else if !errorlevel! equ 3010 (
            echo %GRN%   [OK] x86 ^(Reinicio recomendado depois^)%R%
        ) else if !errorlevel! equ 1638 (
            echo %GRN%   [OK] x86 ^(Ja instalado^)%R%
        ) else (
            echo %RED%   !STR_VC_ERR! (x86) [Cod: !errorlevel!]%R%
            set "VC_ERR=1"
        )
    )
)

echo.
if "!VC_ERR!"=="0" (
    echo %GRN%   !STR_VC_DONE!%R%
) else (
    echo %YLW%   Continuando mesmo assim...%R%
)
echo.
echo %DIM%   Pressione qualquer tecla para continuar...%R%
pause >nul

:MENU
cls
echo.
echo %B%%CYN%   ##  ##   #####        ##  ##  #####  %R%
echo %B%%CYN%   ## ##   ##            ##  ##  ##  ## %R%
echo %B%%CYN%   ####    ## ###        ##  ##  #####  %R%
echo %B%%CYN%   ## ##   ##  ##        ##  ##  ##     %R%
echo %B%%CYN%   ##  ##   #####         ####   ##     %R%
echo.
echo %DIM%   ===============================================%R%
echo %B%%WHT%   !STR_MENU_TITLE!   %DIM%^|%CYN%  v26.x+ (Recentes)%R%
echo %DIM%   ===============================================%R%
echo.
echo   %DIM%YouTube  %WHT%^>^> %CYN%https://youtube.com/@kaio-kgup%R%
echo   %DIM%Discord  %WHT%^>^> %CYN%https://discord.com/invite/fTfamzmsHC%R%
echo.
echo %DIM%   ===============================================%R%
echo.
echo   %CYN%[1]%WHT% !STR_OPT1!%R%
echo   %RED%[2]%WHT% !STR_OPT2!%R%
echo   %DIM%[3] !STR_OPT3!%R%
echo.
echo %DIM%   !STR_HINT!%R%
echo %DIM%   ===============================================%R%
echo.
set "OP="
set /p "OP=   %WHT%!STR_CHOICE!%R%"

if "!OP!"=="1" goto INSTALL
if "!OP!"=="2" goto UNINSTALL
if "!OP!"=="3" goto EXIT_NOW
echo %YLW%   !STR_INVALID!%R%
timeout /t 2 >nul
goto MENU

:INSTALL
cls
echo.
echo %B%%CYN%   ===============================================%R%
echo %B%%CYN%              !STR_OPT1!%R%
echo %B%%CYN%   ===============================================%R%
echo.

set "NEW_VC=%INST_DIR%vcruntime140_1.dll"
set "NEW_MOD=%INST_DIR%KG-UP-GOAT.dll"

if not exist "%NEW_VC%" (
    echo %RED%   !STR_ERR_DLL!%R%
    echo %DIM%   vcruntime140_1.dll%R%
    goto PAUSE_BACK
)
if not exist "%NEW_MOD%" (
    echo %RED%   !STR_ERR_DLL!%R%
    echo %DIM%   KG-UP-GOAT.dll%R%
    goto PAUSE_BACK
)

if not exist "%APPDATA%\Minecraft Bedrock" (
    echo %RED%   !STR_ERR_DATA!%R%
    goto PAUSE_BACK
)

echo %WHT%   !STR_SEARCHING!%R%
set "MC_PATH="
for /f "delims=" %%i in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$pkg = Get-AppxPackage -Name Microsoft.MinecraftUWP -ErrorAction SilentlyContinue; if ($pkg) { Write-Output $pkg.InstallLocation }" 2^>nul') do (
    if not defined MC_PATH set "MC_PATH=%%i"
)

if not defined MC_PATH (
    echo %RED%   !STR_NOT_FOUND!%R%
    goto PAUSE_BACK
)

if not exist "%MC_PATH%\Minecraft.Windows.exe" (
    echo %RED%   !STR_ERR_PATH!%R%
    set "MC_PATH="
    goto PAUSE_BACK
)

echo %GRN%   [OK] !STR_FOUND!: %WHT%%MC_PATH%%R%

tasklist /fi "imagename eq Minecraft.Windows.exe" 2>nul | find /i "Minecraft.Windows.exe" >nul
if not errorlevel 1 (
    echo %RED%   !STR_RUNNING!%R%
    goto PAUSE_BACK
)

if not exist "%MODS_DIR%" mkdir "%MODS_DIR%"
if not exist "%BKP_DIR%" mkdir "%BKP_DIR%"

set "OLD_VC=%MC_PATH%\vcruntime140_1.dll"
if exist "%OLD_VC%" (
    for /f "delims=" %%t in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%t"
    echo %WHT%   !STR_BACKUP!%R%
    copy /y "%OLD_VC%" "%BKP_DIR%\vcruntime140_1_backup_!STAMP!.dll" >nul 2>&1
    echo %GRN%   [OK] !STR_BACKUP_OK!%R%
)

echo %WHT%   !STR_INST_VC!%R%
takeown /f "%OLD_VC%" >nul 2>&1
icacls "%OLD_VC%" /grant "%USERNAME%":F >nul 2>&1
attrib -r "%OLD_VC%" >nul 2>&1
takeown /f "%MC_PATH%" >nul 2>&1
icacls "%MC_PATH%" /grant "%USERNAME%":F >nul 2>&1
copy /y "%NEW_VC%" "%MC_PATH%\vcruntime140_1.dll" >nul 2>&1
if errorlevel 1 (
    echo %RED%   !STR_ERR_VC!%R%
    goto PAUSE_BACK
)
echo %GRN%   [OK] vcruntime140_1.dll%R%

echo %WHT%   !STR_INST_MOD!%R%
copy /y "%NEW_MOD%" "%MODS_DIR%\KG-UP-GOAT.dll" >nul 2>&1
if errorlevel 1 (
    echo %RED%   !STR_ERR_MOD!%R%
    goto PAUSE_BACK
)
echo %GRN%   [OK] KG-UP-GOAT.dll%R%

echo.
echo %B%%GRN%   ===============================================%R%
echo %B%%GRN%    !STR_INST_OK!%R%
echo %B%%GRN%   ===============================================%R%
echo.
echo %WHT%   !STR_RESTART!%R%
echo.

goto PROMPT_COMMUNITY

:PROMPT_COMMUNITY
echo %DIM%   ------------------------------------------------%R%
echo.
echo %B%%YLW%   !STR_COMM_Q!%R%
echo %WHT%   !STR_COMM_MSG!%R%
echo %CYN%   !STR_COMM_DC!%R%
echo.
echo   %CYN%[1]%WHT% !STR_COMM_OPT1!%R%
echo   %DIM%[2] !STR_COMM_OPT2!%R%
echo.
set "CP="
set /p "CP=   %WHT%!STR_CHOICE!%R%"

if "!CP!"=="1" (
    start "" "https://www.youtube.com/@kaio-kgup"
    start "" "https://discord.com/invite/fTfamzmsHC"
    echo.
    echo %GRN%   YouTube e Discord abertos no navegador!%R%
    echo.
)

goto PAUSE_BACK

:UNINSTALL
cls
echo.
echo %B%%RED%   ===============================================%R%
echo %B%%RED%              !STR_UNIN_TITLE!%R%
echo %B%%RED%   ===============================================%R%
echo.

echo %WHT%   !STR_SEARCHING!%R%
set "MC_PATH="
for /f "delims=" %%i in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$pkg = Get-AppxPackage -Name Microsoft.MinecraftUWP -ErrorAction SilentlyContinue; if ($pkg) { Write-Output $pkg.InstallLocation }" 2^>nul') do (
    if not defined MC_PATH set "MC_PATH=%%i"
)

if not defined MC_PATH (
    echo %RED%   !STR_NOT_FOUND!%R%
    goto PAUSE_BACK
)
echo %GRN%   [OK] !STR_FOUND!: %WHT%%MC_PATH%%R%

tasklist /fi "imagename eq Minecraft.Windows.exe" 2>nul | find /i "Minecraft.Windows.exe" >nul
if not errorlevel 1 (
    echo %RED%   !STR_RUNNING!%R%
    goto PAUSE_BACK
)

set "TARGET_VC=%MC_PATH%\vcruntime140_1.dll"
set "BEST_BKP="

for /f "delims=" %%f in ('dir /b /o-d "%BKP_DIR%\vcruntime140_1_backup_*.dll" 2^>nul') do (
    if not defined BEST_BKP set "BEST_BKP=%BKP_DIR%\%%f"
)

if defined BEST_BKP (
    echo %WHT%   !STR_RESTORE!%R%
    takeown /f "%TARGET_VC%" >nul 2>&1
    icacls "%TARGET_VC%" /grant "%USERNAME%":F >nul 2>&1
    attrib -r "%TARGET_VC%" >nul 2>&1
    takeown /f "%MC_PATH%" >nul 2>&1
    icacls "%MC_PATH%" /grant "%USERNAME%":F >nul 2>&1
    copy /y "%BEST_BKP%" "%TARGET_VC%" >nul 2>&1
    echo %GRN%   [OK] !STR_RESTORE_OK!%R%
) else (
    if exist "%TARGET_VC%" (
        echo %YLW%   !STR_NO_BKP!%R%
        takeown /f "%TARGET_VC%" >nul 2>&1
        icacls "%TARGET_VC%" /grant "%USERNAME%":F >nul 2>&1
        attrib -r "%TARGET_VC%" >nul 2>&1
        del /f "%TARGET_VC%" >nul 2>&1
        echo %GRN%   [OK] vcruntime140_1.dll%R%
    ) else (
        echo %DIM%   !STR_NO_VC!%R%
    )
)

set "MOD_FILE=%MODS_DIR%\KG-UP-GOAT.dll"
if exist "%MOD_FILE%" (
    echo %WHT%   !STR_RM_MOD!%R%
    attrib -r "%MOD_FILE%" >nul 2>&1
    del /f "%MOD_FILE%" >nul 2>&1
    echo %GRN%   [OK] !STR_RM_OK!%R%
) else (
    echo %DIM%   !STR_NO_MOD!%R%
)

echo.
echo %B%%GRN%   ===============================================%R%
echo %B%%GRN%    !STR_UNIN_OK!%R%
echo %GRN%    !STR_UNIN_MSG!%R%
echo %B%%GRN%   ===============================================%R%
echo.
echo   %DIM%Discord  %WHT%^>^> %CYN%https://discord.com/invite/fTfamzmsHC%R%
echo.
goto PAUSE_BACK

:PAUSE_BACK
echo.
echo %DIM%   !STR_PRESS!%R%
pause >nul
set "MC_PATH="
goto MENU

:EXIT_NOW
cls
echo.
echo %B%%CYN%   !STR_GOODBYE!%R%
echo %DIM%   v26.x+ (Funciona nas versoes mais recentes)%R%
echo.
echo   %DIM%YouTube  %WHT%^>^> %CYN%https://youtube.com/@kaio-kgup%R%
echo   %DIM%Discord  %WHT%^>^> %CYN%https://discord.com/invite/fTfamzmsHC%R%
echo.
timeout /t 3 >nul
exit /b
